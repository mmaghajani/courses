<html>
<body>
<h1>
<?php
  print "Hello PHP :D ";
  print "Hello PHP :D ";
  date_default_timezone_set('UTC');
  print date("l");
?>
</h1>
</body>
</html>
