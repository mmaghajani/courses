<?php
$abc = phpinfo();
echo $abc;
?>
