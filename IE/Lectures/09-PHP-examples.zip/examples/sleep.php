<?php
echo "time is ". time();
sleep(10);
echo "time is ". time();
sleep(10);
echo "time is ". time();
sleep(10);
echo "time is ". time();
sleep(10);
?>
