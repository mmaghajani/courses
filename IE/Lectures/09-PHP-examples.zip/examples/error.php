<?php
	$tmp=$_REQUEST[1];
	echo 1/$tmp;
?>
