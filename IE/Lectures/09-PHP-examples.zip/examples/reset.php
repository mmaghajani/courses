<?php
session_start();
//unset($_SESSION["cnt"]);
session_destroy();
?>
<html>
<head></head>
<body>Your counter is reset</body>
</html>
