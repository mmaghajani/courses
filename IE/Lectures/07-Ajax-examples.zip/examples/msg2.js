var newp = document.createElement("p");
newp.innerHTML="I am a HTML message";
b = document.getElementsByTagName("body")[0];
b.appendChild(newp);
