<h1>Hi, <?php echo e($firstname); ?>!</h1>

<p>به امیرکبیر استودیو خوش آمدی!</p>
