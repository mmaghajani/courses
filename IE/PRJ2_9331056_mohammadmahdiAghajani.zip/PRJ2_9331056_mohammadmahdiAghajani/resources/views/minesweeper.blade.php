<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="/css/minesweeper.css">
</head>

<body>


<script src="/node_modules/jquery/dist/jquery.min.js"></script>
<script src="https://rawgit.com/AUT-CEIT/ie/master/2016/fall/HW-3/js/lib.js"></script>
<script src="/js/global.js"></script>
<script src="/js/minesweeper.js"></script>
</body>
</html>
