import javax.sql.rowset.spi.SyncResolver;
import java.sql.*;

public class JDBCExample {

    public static void main(String[] argv) throws SQLException {

        System.out.println("-------- PostgreSQL "
                + "JDBC Connection Testing ------------");

        try {

            Class.forName("org.postgresql.Driver");

        } catch (ClassNotFoundException e) {

            System.out.println("Where is your PostgreSQL JDBC Driver? "
                    + "Include in your library path!");
            e.printStackTrace();
            return;

        }

        System.out.println("PostgreSQL JDBC Driver Registered!");

        Connection connection = null;

        try {

            connection = DriverManager.getConnection(
                    "jdbc:postgresql://127.0.0.1:5432/postgres", "postgres",
                    "85491374");

        } catch (SQLException e) {

            System.out.println("Connection Failed! Check output console");
            e.printStackTrace();
            return;

        }

        if (connection != null) {
            System.out.println("You made it, take control your database now!");

            show_q3(connection);
            System.out.println();
            System.out.println();
            System.out.println();
            show_q6(connection);
            System.out.println();
            System.out.println();
            System.out.println();
            show_q7(connection);

        } else {
            System.out.println("Failed to make connection!");
        }
    }

    private static void show_q3(Connection connection) throws SQLException {
        Statement stmt = null;
        String query = "select sum(amount),type from investment group by type";
        try {
            stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            System.out.println(String.format("%-32s %s" , "type" , "amount"));
            while (rs.next()) {
                int amount = rs.getInt(1);
                String type = rs.getString(2);

                System.out.println(String.format("%s %32s" , Integer.toString(amount) , type));
            }
        } catch (SQLException e ) {
            e.printStackTrace();
        } finally {
            if (stmt != null) { stmt.close(); }
        }
    }

    private static void show_q6(Connection connection) throws SQLException {
        Statement stmt = null;
        String query = "select subject ,massive_event.subtitle from (massive_event_intercommunity inner join product on ( product.id = massive_event_intercommunity.product_id )) as t1 inner join public.massive_event on ( t1.event_id = public.massive_event.id)  where type_of_calling = 'refree' \n" +
                "\torder by t1.event_id;";
        try {
            stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            System.out.println(String.format("%-32s %s" , "product_title" , "event_title" ));
            while (rs.next()) {
                String product_title = rs.getString(1);
                String event_title = rs.getString(2);

                System.out.println(String.format("%s %32s" , product_title , event_title));
            }
        } catch (SQLException e ) {
            e.printStackTrace();
        } finally {
            if (stmt != null) { stmt.close(); }
        }
    }

    private static void show_q7(Connection connection) throws SQLException {
        Statement stmt = null;
        String query = "select username,subject from (register_event inner join public.user on ( register_event.user_id = public.user.id )) as t1 inner join public.event on ( t1.event_id = public.event.id ) order by subject;";
        try {
            stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            System.out.println(String.format("%-32s %s" , "usernames" , "event_title" ) );
            while (rs.next()) {
                String username = rs.getString(1);
                String event_title = rs.getString(2);

                System.out.println(String.format( "%-32s %s",  username , event_title));
            }
        } catch (SQLException e ) {
            e.printStackTrace();
        } finally {
            if (stmt != null) { stmt.close(); }
        }
    }

}