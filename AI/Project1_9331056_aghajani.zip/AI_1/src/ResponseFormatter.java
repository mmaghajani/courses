import algorithms.Algorithm;
import data_structures.Node;
import data_structures.QueensNode;
import problems.Problem;

import java.util.ArrayList;

/**
 * Created by mma on 10/31/16.
 */
public class ResponseFormatter {
    private static ResponseFormatter ourInstance = new ResponseFormatter();

    public static ResponseFormatter getInstance() {
        return ourInstance;
    }

    private ResponseFormatter() {
    }

    public void format(ProblemSolvingAgent agent, Node goal) {
        Algorithm algorithm = agent.getSearchAlgorithm();
        String seperator = "----------------------";
        System.out.println(seperator);
        System.out.println("number of expanded nodes : " + algorithm.getNumOfExpandedNode());
        System.out.println("number of visited nodes : " + algorithm.getNumOfVisitedNode());
        System.out.println("number of max used memory : " + algorithm.getMaxUsedMemory());
        System.out.println(seperator);
        System.out.println("Cost of goal : " + goal.getAccessibilityCost() + "\n\n\n");
        Node node = goal;
        ArrayList<Node> path = new ArrayList<>();
        while (node != null) {
            path.add(node);
            node = node.getParent();
        }

        System.out.println("Path : ");
        for (int i = path.size() - 1; i >= 0; i--) {
//            if( path.get(i) instanceof QueensNode ){
//                QueensNode q = (QueensNode) path.get(i);
//                int[] state = (int[]) q.getState();
//                System.out.println(path.get(i).getState()) ;
//            }
            System.out.println(path.get(i));
        }
    }
}
