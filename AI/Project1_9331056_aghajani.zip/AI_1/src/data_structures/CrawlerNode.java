package data_structures;

/**
 * Created by mma on 10/26/16.
 */
public class CrawlerNode extends Node {
    @Override
    public Object getState() {
        return null;
    }
}
