package algorithms.uninformed_search.dfs;

import algorithms.Algorithm;

/**
 * Created by mma on 10/26/16.
 */
public abstract class DFS extends Algorithm {

}
