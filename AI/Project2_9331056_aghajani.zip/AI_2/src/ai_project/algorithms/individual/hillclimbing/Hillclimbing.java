package ai_project.algorithms.individual.hillclimbing;

import ai_project.algorithms.individual.IndividualAlgorithm;

/**
 * Created by mma on 12/8/16.
 */
public abstract class  Hillclimbing extends IndividualAlgorithm{
}
