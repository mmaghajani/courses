//
// Created by aliakbarbadri on 1/14/17.
//

#include <stdio.h>
#include <stdlib.h>

#define FIFO_FILE "MYFIFO"

int main(int argc, char *argv[]) {
    FILE *fp;
    char rb[80];
    if ((fp = fopen(FIFO_FILE, "w")) == NULL) {
        perror("fopen");
        exit(1);
    }
    fputs("request!", fp);
    fclose(fp);
    fp = fopen(FIFO_FILE, "r");
    fgets(rb, 80, fp);
    printf("Time : %s\n", rb);
    fclose(fp);
    return (0);
}