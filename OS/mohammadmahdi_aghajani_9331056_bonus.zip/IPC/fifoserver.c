//
// Created by aliakbarbadri on 1/14/17.
//

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <linux/stat.h>

#define FIFO_FILE "MYFIFO"
#define BUFFER_SIZE 20

char write_msg[BUFFER_SIZE];

char *concatTimes() {
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    char temp[4];
    sprintf(write_msg, "%d", tm.tm_year + 1900);
    strcat(write_msg, "/");
    sprintf(temp, "%d", tm.tm_mon + 1);
    strcat(write_msg, temp);
    strcat(write_msg, "/");
    sprintf(temp, "%d", tm.tm_mday);
    strcat(write_msg, temp);
    strcat(write_msg, " - ");
    sprintf(temp, "%d", tm.tm_hour);
    strcat(write_msg, temp);
    strcat(write_msg, ":");
    sprintf(temp, "%d", tm.tm_min);
    strcat(write_msg, temp);
    strcat(write_msg, ":");
    sprintf(temp, "%d", tm.tm_sec);
    strcat(write_msg, temp);
}

int main(void) {
    FILE *fp;
    char readbuf[80];
    umask(0);
    mknod(FIFO_FILE, S_IFIFO | 0666, 0);
    concatTimes();
    while (1) {
        fp = fopen(FIFO_FILE, "r");
        fgets(readbuf, 80, fp);
        printf("Received string: %s\n", readbuf);
        fclose(fp);
        fp = fopen(FIFO_FILE, "w");
        fputs(write_msg, fp);
        fclose(fp);
    }
    return (0);
}