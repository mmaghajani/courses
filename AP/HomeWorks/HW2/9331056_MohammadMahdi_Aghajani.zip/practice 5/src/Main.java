
public class Main {
	public static void main( String args[] ){
		Date date = new Date( 1 , 1 , 1990 ) ;
		
		date.displayeDate();
	}

	
}
