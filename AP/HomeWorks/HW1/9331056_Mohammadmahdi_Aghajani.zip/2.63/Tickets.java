
/**
 * Write a description of class Ticket here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tickets
{
    int ticket1 ;
    int ticket2 ;
    int ticket3 ;
    
    public Tickets( int price1 , int price2 , int price3 )
    {
        ticket1 = price1 ;
        ticket2 = price2 ;
        ticket3 = price3 ;
    }
}
