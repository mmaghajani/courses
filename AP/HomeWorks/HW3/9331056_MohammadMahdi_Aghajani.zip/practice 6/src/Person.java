
public class Person {
	private int time ;
	
	public Person( int time ){
		this.time = time ;
	}
	
	public int getTime(){
		return time ;
	}

}
