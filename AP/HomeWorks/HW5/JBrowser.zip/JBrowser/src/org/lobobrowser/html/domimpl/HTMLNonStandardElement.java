package org.lobobrowser.html.domimpl;

public class HTMLNonStandardElement extends HTMLElementImpl {
	public HTMLNonStandardElement(String name, boolean noStyleSheet) {
		super(name, noStyleSheet);
	}

	public HTMLNonStandardElement(String name) {
		super(name);
	}
}
