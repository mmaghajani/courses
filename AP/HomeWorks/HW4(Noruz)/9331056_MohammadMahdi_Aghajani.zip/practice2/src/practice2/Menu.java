package practice2;

import java.util.Scanner;

public class Menu {

	public void start() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Pls enter two numbers :");
		BigNum a = new BigNum();
		BigNum b = new BigNum();
		a.input();
		b.input();

		System.out.println("For sum press 1");
		System.out.println("For subtraction press 2");
		System.out.println("For multiplication press 3");
		System.out.println("For compare press 4");
		System.out.println("For check isZero press 5");

		int key = sc.nextInt();
		switch (key) {
		case 1:
			a.sum(b).show();
			break;
		case 2:
			a.subtraction(b).show();
			break;
		case 3:
			a.multiplication(b).show();
			break;
		case 4:
			System.out.println("For check bigger relation press 1");
			System.out.println("For check lower relation press 2");
			System.out.println("For check equal relation press 3");
			System.out.println("For check notEqual relation press 4");
			System.out.println("For check bigger-equal relation press 5");
			System.out.println("For check lower-equal relation press 6");

			key = sc.nextInt();
			switch (key) {
			case 1:
				System.out.println(a.isBigger(b));
				break;
			case 2:
				System.out.println(b.isBigger(a));
				break;
			case 3:
				System.out.println(a.isEqual(b));
				break;
			case 4:
				System.out.println(!a.isEqual(b));
				break;
			case 5:
				if (a.isBigger(b) == true || a.isEqual(b) == true)
					System.out.println("true");
				else
					System.out.println("false");
				break;
			case 6:
				if (b.isBigger(a) == true || a.isEqual(b) == true)
					System.out.println("true");
				else
					System.out.println("false");
				break;
			}

			break;
		case 5:
			System.out.println("first number is zero ? " + a.isZero());
			System.out.println("second number is zero ? " + b.isZero());
			break;
		}
	}
}
