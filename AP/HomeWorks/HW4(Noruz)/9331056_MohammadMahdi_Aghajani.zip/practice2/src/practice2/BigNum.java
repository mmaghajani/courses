package practice2;

import java.util.ArrayList;
import java.util.Scanner;

public class BigNum {
	private ArrayList<Integer> digits;
	private int sign;

	public BigNum(String digits) {
		this.digits = new ArrayList<Integer>();

		if (digits.charAt(0) == '-') {
			sign = -1;

			for (int i = digits.length() - 1; i > 0; i--)
				this.digits.add((int) digits.charAt(i) - 48);
		} else {
			sign = 1;

			for (int i = digits.length() - 1; i >= 0; i--)
				this.digits.add((int) digits.charAt(i) - 48);
		}
	}

	public BigNum() {
		digits = new ArrayList<Integer>();
		sign = 1;
	}

	public ArrayList<Integer> getDigits() {
		return digits;
	}

	public int getSign() {
		return sign;
	}

	private void setSign(int s) {
		sign = s;
	}

	private void negative() {
		sign *= -1;
	}

	public BigNum sum(BigNum a) {
		if (sign == 1 && a.getSign() == -1) {
			a.setSign(1);
			return subtraction(a);
		} else if (sign == -1 && a.getSign() == 1) {
			sign = 1;
			BigNum temp = subtraction(a);
			temp.negative();
			return temp;
		} else {
			BigNum product = new BigNum();
			int temp;

			product.getDigits().add(0);
			for (int i = 0; i < Math.min(digits.size(), a.getDigits().size()); i++) {
				temp = product.getDigits().get(i);

				product.getDigits().set(i,
						mod(digits.get(i) + a.getDigits().get(i) + temp, 10));
				product.getDigits().add(
						(digits.get(i) + a.getDigits().get(i) + temp) / 10);
			}

			if (digits.size() > a.getDigits().size())
				for (int i = a.getDigits().size(); i < digits.size(); i++) {
					temp = product.getDigits().get(i);

					product.getDigits().set(i, mod(digits.get(i) + temp, 10));
					product.getDigits().add((digits.get(i) + temp) / 10);
				}
			else if (digits.size() < a.getDigits().size())
				for (int i = digits.size(); i < a.getDigits().size(); i++) {
					temp = product.getDigits().get(i);

					product.getDigits().set(i,
							mod(a.getDigits().get(i) + temp, 10));
					product.getDigits().add((a.getDigits().get(i) + temp) / 10);
				}

			if (sign == -1) {
				product.setSign(-1);
				return product;
			} else
				return product;
		}
	}

	public BigNum subtraction(BigNum a) {
		if (sign == 1 && a.getSign() == -1) {
			a.setSign(1);
			return sum(a);
		} else if (sign == -1 && a.getSign() == 1) {
			sign = 1;
			BigNum temp = sum(a);
			temp.negative();
			return temp;
		} else {
			BigNum product = new BigNum();
			int temp = 0;

			if (isBigger(a)) {
				product.getDigits().add(0);
				for (int i = 0; i < a.getDigits().size(); i++) {
					product.getDigits()
							.set(i,
									mod(digits.get(i) - a.getDigits().get(i)
											+ temp, 10));

					if (digits.get(i) + temp < a.getDigits().get(i))
						temp = -1;
					else
						temp = 0;
					product.getDigits().add(0);
				}

				for (int i = a.getDigits().size(); i < digits.size(); i++) {
					product.getDigits().set(i, mod(digits.get(i) + temp, 10));

					if (digits.get(i) + temp < 0)
						temp = -1;
					else
						temp = 0;
					product.getDigits().add(0);
				}

				if (sign == -1) {
					product.setSign(-1);
					return product;
				} else
					return product;

			} else {
				product.getDigits().add(0);
				for (int i = 0; i < digits.size(); i++) {
					product.getDigits()
							.set(i,
									mod(a.getDigits().get(i) - digits.get(i)
											+ temp, 10));

					if (a.getDigits().get(i) + temp < digits.get(i))
						temp = -1;
					else
						temp = 0;
					product.getDigits().add(0);
				}

				for (int i = digits.size(); i < a.getDigits().size(); i++) {
					product.getDigits().set(i,
							mod(a.getDigits().get(i) + temp, 10));

					if (a.getDigits().get(i) + temp < 0)
						temp = -1;
					else
						temp = 0;
					product.getDigits().add(0);
				}

				if (sign == -1)
					return product;
				else {
					product.setSign(-1);
					return product;
				}

			}
		}

	}

	public BigNum multiplication(BigNum a) {
		BigNum product = new BigNum();

		for (int i = 0; i < a.getDigits().size(); i++) {
			int index = i;

			for (int j = 0; j < digits.size(); j++) {
				if (product.getDigits().size() - 1 < index) {
					product.getDigits().add(
							mod(digits.get(j) * a.getDigits().get(i), 10));

					product.getDigits().add(
							digits.get(j) * a.getDigits().get(i) / 10);
				} else {
					if (product.getDigits().size() - 1 < index + 1) {
						int temp = product.getDigits().get(index);
						product.getDigits()
								.set(index,
										mod(temp + digits.get(j)
												* a.getDigits().get(i), 10));

						product.getDigits()
								.add((temp + digits.get(j)
										* a.getDigits().get(i)) / 10);
					} else {
						int temp = product.getDigits().get(index);
						product.getDigits()
								.set(index,
										mod(temp + digits.get(j)
												* a.getDigits().get(i), 10));

						product.getDigits().set(
								index + 1,
								product.getDigits().get(index + 1)
										+ (temp + digits.get(j)
												* a.getDigits().get(i)) / 10);
					}
				}
				index++;
			}

		}

		if (sign == -1 && a.getSign() == 1) {
			product.setSign(-1);
			return product;
		} else if (sign == -1 && a.getSign() == -1)
			return product;
		else if (sign == 1 && a.getSign() == -1) {
			product.setSign(-1);
			return product;
		} else
			return product;
	}

	public boolean isBigger(BigNum a) {
		if (digits.size() > a.getDigits().size())
			return true;
		else if (digits.size() < a.getDigits().size())
			return false;
		else {
			int index = digits.size() - 1;
			while (digits.get(index) == a.getDigits().get(index))
				index--;

			if (digits.get(index) > a.getDigits().get(index))
				return true;
			else
				return false;
		}
	}

	public boolean isEqual(BigNum a) {
		if (digits.size() != a.getDigits().size())
			return false;
		else
			for (int i = 0; i < digits.size(); i++)
				if (digits.get(i) != a.getDigits().get(i))
					return false;
		return true;
	}

	public boolean isZero() {
		for (int i = 0; i < digits.size(); i++)
			if (digits.get(i) != 0)
				return false;
		return true;
	}

	public void input() {
		String digits;
		Scanner sc = new Scanner(System.in);
		digits = sc.next();

		if (digits.charAt(0) == '-') {
			sign = -1;
			for (int i = digits.length() - 1; i > 0; i--)
				this.digits.add((int) digits.charAt(i) - 48);
		} else {
			sign = 1;
			for (int i = digits.length() - 1; i >= 0; i--)
				this.digits.add((int) digits.charAt(i) - 48);
		}
	}

	public void show() {
		while (digits.get(digits.size() - 1) == 0)
			digits.remove(digits.size() - 1);

		if (sign == -1)
			System.out.print("-");

		for (int i = digits.size() - 1; i >= 0; i--)
			System.out.print(digits.get(i));
	}

	public String toString() {
		ArrayList<Integer> temp = new ArrayList<Integer>();

		for (int i = digits.size() - 1; i >= 0; i--)
			temp.add(digits.get(i));

		while (temp.get(0) == 0)
			temp.remove(0);

		return temp.toString();
	}

	private int mod(int x, int y) {
		if (x >= 0)
			return x % y;
		else
			return (x % y) + y;
	}

}
