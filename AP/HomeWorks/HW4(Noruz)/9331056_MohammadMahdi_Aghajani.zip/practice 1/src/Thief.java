public class Thief extends Human {

	public Thief(int xPos, int yPos) {
		super(xPos, yPos);
		visibleThiefPosition = null;
		setIsPolice(false);
		// TODO Auto-generated constructor stub
	}

	public Thief(){
		super() ;
		visibleThiefPosition = null ;
		setIsPolice(false);
	}
	@Override
	public void move( Size size , char[][] map) {

		previouesPos.assign(pos);
		this.pos = randomMove( size , map ) ;
		numOfMovement++ ;
		
		if( visibleThiefPosition != null )
			visibleThiefPosition = this.pos ;
		// TODO Auto-generated method stub

	}	
	@Override
	protected boolean isValidPosition( Position pos , Size size , char[][] map){
		if( pos.x >= size.length || pos.y >= size.width || pos.x < 0 || pos.y < 0 )
			return false ;
		return true ;
	}


}
