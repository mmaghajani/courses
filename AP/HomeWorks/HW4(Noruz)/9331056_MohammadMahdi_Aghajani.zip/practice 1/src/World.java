import java.awt.AWTException;
import java.awt.Cursor;
import java.awt.Robot;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class World {
	private char[][] map;
	private final Size size;
	private int time;
	private final int numOfPolices;
	private Human[] humans;

	public World(int length, int width, int numOfPolices) {
		size = new Size(length, width);
		map = new char[size.width][size.length];
		setMap();

		time = 0;
		this.numOfPolices = numOfPolices;

		humans = new Human[numOfPolices+1] ;
		preparing();
		printMap();
		System.out.println() ;
	}

	public void start() {
		boolean thiefMistake = false ;
		boolean flag = false ;
		do {
			for(Human human : humans )
				if( human.getIsPolice() == true )
					if( ((Police) human).lookAroundToFindThief(map,size) == true )
						flag = true ;
			
			if( flag == false )
				humans[1].visibleThiefPosition = null ;
			
			for (Human human : humans) {
				human.move(size, map);
				if (isCatchedThief() == true){
					if( human.getIsPolice() == false )
						thiefMistake = true ;
					break;
				}
			}
			
			time++;
			
		//	char[][]mapTemp = new char[size.width][size.length] ;
			//assign( mapTemp , map ) ;
			
			setMap() ;
			for(Human human : humans ){
				if( human.getIsPolice() == true ){
					if( map[human.pos.y][human.pos.x] != 'P' )
						put(human) ;
					else {
						human.pos = human.previouesPos ;
						put(human) ;
						human.numOfMovement-- ;
					}
				}
				else
					put(human) ;
			}
			
			try {
				TimeUnit.SECONDS.sleep(2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			printMap() ;
			System.out.println();
			
		} while (isCatchedThief() == false);

		if( thiefMistake == true )
			System.out.println( "Thief mistaked and is catched by polices!" ) ;
		else
			System.out.println( "Polices succeed and catched thief!" ) ;

		System.out.println("Number of thief movement : " + humans[0].getNumOfMovement() );
		
		int sumTemp = 0 ;
		for( int i = 1 ; i <= numOfPolices ; i++ )
			sumTemp += humans[i].getNumOfMovement() ;
		System.out.println("Number of polices movements : " + sumTemp );
	}

	private void setMap() {
		for (int i = 0; i < size.length; i++)
			for (int j = 0; j < size.width; j++)
				map[j][i] = '-';
	}

	private boolean isValidPos(Position pos) {
		if (pos.x >= size.length || pos.y >= size.width)
			return false;
		else if (map[pos.y][pos.x] == '-')
			return true;
		else
			return false;
	}

	private void put(Human human) {
		if (human.getIsPolice() == true)
			map[human.getPos().y][human.getPos().x] = 'P';
		else
			map[human.getPos().y][human.getPos().x] = 'D';
	}

	private void clear(Human human) {
		map[human.getPos().y][human.getPos().x] = '-';
	}

	private boolean isCatchedThief() {
		Position pos = humans[0].getPos();
		for (int i = 1; i <= numOfPolices; i++)
			if (humans[i].getPos().equals(pos))
				return true;
		return false;
	}

	private void preparing() {
		Random rand = new Random();

		for (int i = 1; i <= numOfPolices; i++)
			humans[i] = new Police();
		humans[0] = new Thief();

		for (Human human : humans) {
			Position pos;
			do {
				pos = new Position(Math.abs(rand.nextInt()) % size.length,
						Math.abs(rand.nextInt()) % size.width);
			} while (!isValidPos(pos));

			human.setPos(pos);
			put(human);
		}
	}
	
	private void printMap(){
		//Console c ;
		for( int i = 0 ; i < size.width ; i++ ){
			
		//	c.writer().
			
		/*	try {
			    // These coordinates are screen coordinates
			    int xCoord = 0;
			    int yCoord = 0;

			    // Move the cursor
			    Robot robot = new Robot();
			    robot.mouseMove(xCoord, yCoord);
			} catch (AWTException e) {
			}
			
		/*	char escCode = 0x1B;
			int row = 0; int column = 0;
			System.out.print(String.format("%c[%d;%df",escCode,row,column));
			*/
		//	c.putString(map[i]);
		//	System.console().
			
			System.out.println( map[i] ) ;
		}
		
	//	for( int j = 0 ; j < 20 ; j++ )
		//	System.out.println();
		//c.printScreen();
	}
	
/*	private void assign( char[][]mapTemp , char[][]map){
		for( int i = 0 ; i < size.width ; i++ )
			for( int j = 0 ; j <= size.length ; j++ )
				mapTemp[i][j] = map[i][j] ;
	}
*/
}
