import java.util.Random;
import java.util.Stack;


public abstract class Human {
	protected Position pos ;
	private boolean isPolice ;
	protected static Position visibleThiefPosition ; 
	protected int numOfMovement ;
	protected Position previouesPos ; 
	
	public Human(int xPos , int yPos){
		pos = new Position( xPos , yPos ) ;
		numOfMovement = 0 ;
		previouesPos = new Position() ;
		//previouesPos = null ;
	}
	
	public Human(){
		pos = new Position() ;
		previouesPos = new Position() ;
		//previouesPos = null ;
		numOfMovement = 0 ;
	}
	
	public void setIsPolice(boolean b){
		isPolice = b ;
	}
	
	public boolean getIsPolice(){
		return isPolice ;
	}
	
	public void setPos( Position pos ){
		this.pos = pos ;
	}
	
	public Position getPos(){
		return pos ;
	}
	
	public int getNumOfMovement(){
		return numOfMovement ;
	}
	
	protected Position randomMove( Size size , char[][] map){
		Random rand = new Random();
		Position pos = new Position();

		do {
			pos.x = rand.nextInt() % 2 + this.pos.x;
			pos.y = rand.nextInt() % 2 + this.pos.y;
		} while (!isValidPosition( pos , size , map) || ( pos.x == this.pos.x && pos.y == this.pos.y) );
		
		return pos ;
	}
	
	abstract public void move(Size size , char[][] map );
	
	abstract protected boolean isValidPosition( Position pos , Size size , char[][] map ) ;
}
