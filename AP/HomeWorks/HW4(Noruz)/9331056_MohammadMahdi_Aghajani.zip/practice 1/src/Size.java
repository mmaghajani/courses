
public class Size {
	int length ;
	int width ;
	
	Size( int length , int width ){
		this.length = length ;
		this.width = width ;
	}
}
