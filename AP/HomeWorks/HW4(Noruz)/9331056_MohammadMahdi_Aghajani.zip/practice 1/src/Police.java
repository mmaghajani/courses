public class Police extends Human {
	// private Position thiefPos ;
	// private boolean isAware;

	public Police(int xPos, int yPos) {
		super(xPos, yPos);
		// thiefPos = new Position() ;
		// isAware = false;
		setIsPolice(true);
	}

	public Police() {
		super();
		// isAware = false ;
		setIsPolice(true);
	}

	@Override
	public void move(Size size, char[][] map) {
		scanAround(size, map);
		previouesPos.assign(pos);
		if (visibleThiefPosition == null) {
			this.pos = randomMove(size, map);
			//System.out.println("1");
		} else {
			if (visibleThiefPosition.x <= pos.x + 1
					&& visibleThiefPosition.x >= pos.x - 1
					&& visibleThiefPosition.y < pos.y - 1) {
				pos.y = pos.y - 1;
				//System.out.println("2");
				if (!isValidPosition(pos, size, map)) {
					pos.y = pos.y + 1;
					this.pos = randomMove(size, map);
					//System.out.println("3");
				}
			} else if (visibleThiefPosition.x <= pos.x + 1
					&& visibleThiefPosition.x >= pos.x - 1
					&& visibleThiefPosition.y > pos.y + 1) {
				pos.y = pos.y + 1;
				//System.out.println("4");
				if (!isValidPosition(pos, size, map)) {
					pos.y = pos.y - 1;
					this.pos = randomMove(size, map);
				//	System.out.println("5");
				}
			} else if (visibleThiefPosition.y <= pos.y + 1
					&& visibleThiefPosition.y >= pos.y - 1
					&& visibleThiefPosition.x < pos.x - 1) {
				pos.x = pos.x - 1;
			//	System.out.println("6");
				if (!isValidPosition(pos, size, map)) {
					pos.x = pos.x + 1;
					this.pos = randomMove(size, map);
				//	System.out.println("7");
				}
			} else if (visibleThiefPosition.y <= pos.y + 1
					&& visibleThiefPosition.y >= pos.y - 1
					&& visibleThiefPosition.x > pos.x + 1) {
				pos.x = pos.x + 1;
				//System.out.println("8");
				if (!isValidPosition(pos, size, map)) {
					pos.x = pos.x - 1;
					this.pos = randomMove(size, map);
					//System.out.println("9");
				}
			} else if (visibleThiefPosition.x > pos.x + 1
					&& visibleThiefPosition.y < pos.y - 1) {
				pos.x = pos.x + 1;
				pos.y = pos.y - 1;
				//System.out.println("10");
				if (!isValidPosition(pos, size, map)) {
					pos.y = pos.y + 1;
					pos.x = pos.x - 1;
					this.pos = randomMove(size, map);
					//System.out.println("11");
				}
			} else if (visibleThiefPosition.x < pos.x - 1
					&& visibleThiefPosition.y < pos.y - 1) {
				pos.x = pos.x - 1;
				pos.y = pos.y - 1;
				//System.out.println("12");
				if (!isValidPosition(pos, size, map)) {
					pos.y = pos.y + 1;
					pos.x = pos.x + 1;
					this.pos = randomMove(size, map);
					//System.out.println("13");
				}
			} else if (visibleThiefPosition.x < pos.x - 1
					&& visibleThiefPosition.y > pos.y + 1) {
				pos.x = pos.x - 1;
				pos.y = pos.y + 1;
				//System.out.println("14");
				if (!isValidPosition(pos, size, map)) {
					pos.y = pos.y - 1;
					pos.x = pos.x + 1;
					this.pos = randomMove(size, map);
					//System.out.println("15");
				}
			} else if (visibleThiefPosition.x > pos.x + 1
					&& visibleThiefPosition.y > pos.y + 1) {
				pos.x = pos.x + 1;
				pos.y = pos.y + 1;
				//System.out.println("16");
				if (!isValidPosition(pos, size, map)) {
					pos.y = pos.y - 1;
					pos.x = pos.x - 1;
					this.pos = randomMove(size, map);
					//System.out.println("17");
				}
			} else
				pos = visibleThiefPosition;
			//System.out.println("18");
		}
		// TODO Auto-generated method stub
		numOfMovement++;
	}

	public boolean lookAroundToFindThief(char[][] map , Size size) {
		for (int i = pos.x - 1; i <= pos.x + 1; i++)
			for (int j = pos.y - 1; j <= pos.y + 1; j++){
				Position pos = new Position( i , j ) ;
				if( isValidPosition(pos, size, map))
					if (map[j][i] == 'D')
						return true;
			}
		return false;
	}

	/*
	 * public void setThiefPosition( Position pos ){ thiefPos = pos ; }
	 */
	/*
	 * public void setIsAware(boolean b) { isAware = b; }
	 */
	/*
	 * public boolean getIsAware() { return isAware; }
	 */
	@Override
	protected boolean isValidPosition(Position pos, Size size, char[][] map) {
		if (pos.x >= size.length || pos.y >= size.width || pos.x < 0
				|| pos.y < 0)
			return false;
		else if (map[pos.y][pos.x] == 'P')
			return false;
		return true;
	}

	/*
	 * public Position getThiefPosition(){ return thiefPos ; }
	 */
	private void scanAround(Size size, char[][] map) {
		//System.out.println("20 " + pos.x + " " + pos.y);
		for (int i = pos.y - 2; i <= pos.y + 2; i++)
			for (int j = pos.x - 2; j <= pos.x + 2; j++)
				if (i >= 0 && i < size.width && j >= 0 && j < size.length)
					if (map[i][j] == 'D') {
						Position pos = new Position(j, i);
						visibleThiefPosition = new Position();
						visibleThiefPosition.assign(pos);
						//System.out.println("19");
					}
	}
}
