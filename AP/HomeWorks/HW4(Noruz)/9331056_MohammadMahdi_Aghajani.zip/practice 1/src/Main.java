import java.util.Scanner;


public class Main {
	public static void main( String args[] ){
		Scanner sc = new Scanner( System.in); 
		
		System.out.println("Pls enter length of map") ;
		int length = sc.nextInt() ;
		System.out.println( "Pls enter width of map") ;
		int width = sc.nextInt() ;
		System.out.println( "Pls enter number of polices") ;
		int numOfPolices = sc.nextInt() ;
		
		World world = new World(length, width, numOfPolices);
		world.start() ;

	}

}
