import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Scanner;

public class Game {

	protected char[][] chess;
	private ArrayList<Man> mans1;
	private ArrayList<Man> mans2;
	protected ArrayList<Man> coomadi;

	public Game() {
		mans1 = new ArrayList<Man>();
		mans2 = new ArrayList<Man>();
		chess = new char[9][9];
		coomadi = new ArrayList<Man>();

		setChess();
		setMans();

		for (int i = 0; i < 20; i++) {
			put(mans1.get(i));
			put(mans2.get(i));
		}

	}

	public void start() {
		Scanner sc = new Scanner(System.in);
		Position pos = new Position();
		int xPos, yPos, x;
		boolean end = false;

		while (true) {

			printChess();
			printCoomadi();

			System.out.println();
			System.out.println("First person");
			System.out.println();

			do {
				System.out
						.println("for put a man press 1 and for move a man press another key :");
				x = sc.nextInt();
			} while (x == 1 && coomadi.isEmpty());

			if (x == 1) {

				do {
					System.out
							.println("enter index of man in coomadi (start from zero)");
					x = sc.nextInt();
				} while (x >= coomadi.size());

				System.out.println("Pls enter position for put this man ");

				do {
					System.out.println("Pls enter xPos :");
					xPos = sc.nextInt();
					System.out.println(" Pls enter yPos : ");
					yPos = sc.nextInt();
				} while (xPos > 8 || yPos > 8 || xPos < 0 || yPos < 0
						|| chess[yPos][xPos] != '-');

				pos.x = xPos;
				pos.y = yPos;

				popFromCoomadi(x, pos, "first");

			} else {

				System.out.println("Pls enter man position to move :");

				do {
					System.out.println("Pls enter xPos : ");
					xPos = sc.nextInt();

					System.out.println("Pls enter yPos : ");
					yPos = sc.nextInt();
				} while (xPos > 8 || xPos < 0 || yPos > 8 || yPos < 0
						|| (int) chess[yPos][xPos] < 65
						|| (int) chess[yPos][xPos] > 90);

				pos.x = xPos;
				pos.y = yPos;

				for (Man man : mans1) {
					if (man.pos.equals(pos)) {
						printMoves(man);

						do {
							System.out.println("Pls enter moveNum : ");
							x = sc.nextInt();
						} while (!man.getAvailablePosition(chess).keySet()
								.contains(x));
						
						clear(man);
						man.setPos(man.getAvailablePosition(chess).get(x));
						if (chess[man.pos.y][man.pos.x] == '-')
							put(man);
						else {
							for (int i = 0; i < mans2.size(); i++) {
								if (mans2.get(i).pos.equals(man.pos)) {
									coomadi.add(mans2.get(i));
									mans2.get(i).pos.reset();
									mans2.remove(i);
									put(man);
									break;
								}
							}
						}

						break;
					}
				}
			}

			if (isMatKing("second")) {
				printChess();
				System.out.println("first person is winner!");
				break;
			}
			if (isMatKing("first")) {
				printChess();
				System.out.println("second person is winner!");
				break;
			}

			printChess();
			printCoomadi();

			System.out.println();
			System.out.println("Second person");
			System.out.println();

			do {
				System.out
						.println("for put a man press 1 and for move a man press another key :");
				x = sc.nextInt();
			} while (x == 1 && coomadi.isEmpty());

			if (x == 1) {
				do {
					System.out
							.println("enter index of man in coomadi (start from zero)");
					x = sc.nextInt();
				} while (x >= coomadi.size());

				System.out.println("Pls enter position for put this man ");
				do {
					System.out.println("Pls enter xPos :");
					xPos = sc.nextInt();
					System.out.println(" Pls enter yPos : ");
					yPos = sc.nextInt();
				} while (xPos > 8 || yPos > 8 || xPos < 0 || yPos < 0
						|| chess[yPos][xPos] != '-');

				pos.x = xPos;
				pos.y = yPos;

				popFromCoomadi(x, pos, "second");

			} else {
				System.out.println("Pls enter man position to move :");

				do {
					System.out.println("Pls enter xPos : ");
					xPos = sc.nextInt();

					System.out.println("Pls enter yPos : ");
					yPos = sc.nextInt();
				} while (xPos > 8 || xPos < 0 || yPos > 8 || yPos < 0
						|| (int) chess[yPos][xPos] < 65
						|| (int) chess[yPos][xPos] > 90);

				pos.x = xPos;
				pos.y = yPos;

				for (Man man : mans2) {
					if (man.pos.equals(pos)) {
						printMoves(man);
						
						do {
							System.out.println("Pls enter moveNum : ");
							x = sc.nextInt();
						} while (!man.getAvailablePosition(chess).keySet()
								.contains(x));
						
						clear(man);
						man.setPos(man.getAvailablePosition(chess).get(x));

						if (chess[man.pos.y][man.pos.x] == '-')
							put(man);
						else {
							for (int i = 0; i < mans1.size(); i++) {
								if (mans1.get(i).pos.equals(man.pos)) {
									coomadi.add(mans1.get(i));
									mans1.get(i).pos.reset();
									mans1.remove(i);
									put(man);
									break;
								}
							}
						}

						break;
					}
				}
			}

			if (isMatKing("first")) {
				printChess();
				System.out.println("second person is winner!");
				break;
			}

			if (isMatKing("second")) {
				printChess();
				System.out.println("first person is winner!");
				break;
			}
		}
	}

	private void setChess() {
		for (int i = 0; i < 9; i++)
			for (int j = 0; j < 9; j++)
				chess[i][j] = '-';
	}

	private void setMans() {
		Position pos = new Position();

		pos.x = 4;
		pos.y = 8;
		mans1.add(new King(pos, "first", 1, 'K'));

		pos.x = 3;
		pos.y = 8;
		mans1.add(new GoldGeneral(pos, "first", 1, 'G'));

		pos.x = 5;
		pos.y = 8;
		mans1.add(new GoldGeneral(pos, "first", 1, 'G'));

		pos.x = 2;
		pos.y = 8;
		mans1.add(new SilverGeneral(pos, "first", 1, 'S'));

		pos.x = 6;
		pos.y = 8;
		mans1.add(new SilverGeneral(pos, "first", 1, 'S'));

		pos.x = 1;
		pos.y = 8;
		mans1.add(new Knight(pos, "first", 1, 'N'));

		pos.x = 7;
		pos.y = 8;
		mans1.add(new Knight(pos, "first", 1, 'N'));

		pos.x = 0;
		pos.y = 8;
		mans1.add(new Lance(pos, "first", 1, 'L'));

		pos.x = 8;
		pos.y = 8;
		mans1.add(new Lance(pos, "first", 1, 'L'));

		pos.x = 7;
		pos.y = 7;
		mans1.add(new Rook(pos, "first", 1, 'R'));

		pos.x = 1;
		pos.y = 7;
		mans1.add(new Bishop(pos, "first", 1, 'B'));

		for (int i = 0; i < 9; i++) {
			pos.y = 6;
			pos.x = i;
			mans1.add(new Pawn(pos, "first", 1, 'P'));
		}

		pos.x = 4;
		pos.y = 0;
		mans2.add(new King(pos, "second", -1, 'K'));

		pos.x = 3;
		pos.y = 0;
		mans2.add(new GoldGeneral(pos, "second", -1, 'G'));

		pos.x = 5;
		pos.y = 0;
		mans2.add(new GoldGeneral(pos, "second", -1, 'G'));

		pos.x = 2;
		pos.y = 0;
		mans2.add(new SilverGeneral(pos, "second", -1, 'S'));

		pos.x = 6;
		pos.y = 0;
		mans2.add(new SilverGeneral(pos, "second", -1, 'S'));

		pos.x = 1;
		pos.y = 0;
		mans2.add(new Knight(pos, "second", -1, 'N'));

		pos.x = 7;
		pos.y = 0;
		mans2.add(new Knight(pos, "second", -1, 'N'));

		pos.x = 0;
		pos.y = 0;
		mans2.add(new Lance(pos, "second", -1, 'L'));

		pos.x = 8;
		pos.y = 0;
		mans2.add(new Lance(pos, "second", -1, 'L'));

		pos.x = 7;
		pos.y = 1;
		mans2.add(new Rook(pos, "second", -1, 'R'));

		pos.x = 1;
		pos.y = 1;
		mans2.add(new Bishop(pos, "second", -1, 'B'));

		for (int i = 0; i < 9; i++) {
			pos.y = 2;
			pos.x = i;
			mans2.add(new Pawn(pos, "second", -1, 'P'));
		}

	}

	private void put(Man man) {
		chess[man.pos.y][man.pos.x] = man.shownChar;
	}

	private void clear(Man man) {
		chess[man.pos.y][man.pos.x] = '-';
	}

	private boolean isMatKing(String owner) {
		if (owner.equals("first")) {
			Collection<Position> aroundValidPos = new ArrayList<Position>();
			aroundValidPos = mans1.get(0).getAvailablePosition(chess).values();

			if (!isInEnemyBoard(mans1.get(0).pos, owner))
				return false;

			for (Position pos : aroundValidPos) {
				char temp = chess[pos.y][pos.x];
				chess[pos.y][pos.x] = 'K';
				chess[mans1.get(0).pos.y][mans1.get(0).pos.x] = '-';

				if (!isInEnemyBoard(pos, owner)) {
					chess[mans1.get(0).pos.y][mans1.get(0).pos.x] = 'K';
					chess[pos.y][pos.x] = temp;
					return false;
				}

				chess[mans1.get(0).pos.y][mans1.get(0).pos.x] = 'K';
				chess[pos.y][pos.x] = temp;
			}

			return true;
		} else {
			Collection<Position> aroundValidPos = new ArrayList<Position>();
			aroundValidPos = mans2.get(0).getAvailablePosition(chess).values();

			if (!isInEnemyBoard(mans2.get(0).pos, owner))
				return false;

			for (Position pos : aroundValidPos) {
				char temp = chess[pos.y][pos.x];
				chess[pos.y][pos.x] = 'k';
				chess[mans2.get(0).pos.y][mans2.get(0).pos.x] = '-';

				if (!isInEnemyBoard(pos, owner)) {
					chess[mans2.get(0).pos.y][mans2.get(0).pos.x] = 'k';
					chess[pos.y][pos.x] = temp;
					return false;
				}

				chess[mans2.get(0).pos.y][mans2.get(0).pos.x] = 'k';
				chess[pos.y][pos.x] = temp;
			}

			return true;

		}
	}

	private boolean isInEnemyBoard(Position pos, String owner) {
		Collection<Position> temp = new ArrayList<Position>();
		if (owner == "first") {
			for (Man man : mans2) {
				temp = man.getAvailablePosition(chess).values();
				for (Position position : temp) {
					if (position.equals(pos))
						return true;
				}
			}

			return false;
		} else {
			for (Man man : mans1) {
				temp = man.getAvailablePosition(chess).values();
				for (Position position : temp) {
					if (position.equals(pos))
						return true;
				}
			}

			return false;
		}
	}

	private void popFromCoomadi(int x, Position pos, String owner) {
		if (owner == "first") {
			coomadi.get(x).setPos(pos);
			coomadi.get(x).setOwner("first");
			coomadi.get(x).setShownChar(
					(char) (coomadi.get(x).getShownChar() - 32));
			coomadi.get(x).face = 1;
			mans1.add(coomadi.get(x));
			chess[coomadi.get(x).pos.y][coomadi.get(x).pos.x] = coomadi.get(x).shownChar;
			coomadi.remove(x);
		} else {
			coomadi.get(x).setPos(pos);
			coomadi.get(x).setOwner("second");
			coomadi.get(x).setShownChar(
					(char) (coomadi.get(x).getShownChar() + 32));
			coomadi.get(x).face = -1;
			mans2.add(coomadi.get(x));
			chess[coomadi.get(x).pos.y][coomadi.get(x).pos.x] = coomadi.get(x).shownChar;
			coomadi.remove(x);
		}

	}

	private void printChess() {
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				System.out.print(chess[i][j]);
				System.out.print(" ");
			}
			System.out.println();
		}
	}

	private void printMoves(Man man) {
		HashMap<Integer, Position> temp = new HashMap<Integer, Position>();
		temp = man.getAvailablePosition(chess);
		for (Integer x : temp.keySet()) {
			System.out.print(x);
			System.out.print(" : ");
			System.out.print(temp.get(x).y);
			System.out.print(" ");
			System.out.print(temp.get(x).x);
			System.out.println();
		}

	}

	private void printCoomadi() {
		System.out.println();
		System.out.print("Coomadi is : [ ");
		for (int i = 0; i < coomadi.size(); i++) {
			System.out.print(coomadi.get(i).getShownChar() + " ");
		}
		System.out.println("]");
		System.out.println();
	}

}
