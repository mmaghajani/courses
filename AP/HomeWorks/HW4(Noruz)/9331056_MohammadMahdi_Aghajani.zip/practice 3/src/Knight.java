import java.util.HashMap;

public class Knight extends Man {

	public Knight(Position pos, String owner, int face, char c) {
		super(pos, owner, face, c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public HashMap<Integer, Position> getAvailablePosition(char[][] chess) {
		HashMap<Integer, Position> GAP = new HashMap<Integer, Position>();

		Position pos1 = new Position();
		pos1.assign(this.pos);
		pos1.y -= (face * 2);
		pos1.x += face;
		if (isValidPosition(pos1, chess))
			GAP.put(1, pos1);

		Position pos2 = new Position();
		pos2.assign(this.pos);
		pos2.y -= (face * 2);
		pos2.x -= face;
		if (isValidPosition(pos2, chess))
			GAP.put(2, pos2);

		return GAP;
	}

}
