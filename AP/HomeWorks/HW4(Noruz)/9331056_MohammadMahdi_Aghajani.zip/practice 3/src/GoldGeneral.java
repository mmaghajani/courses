import java.util.HashMap;

public class GoldGeneral extends Man {

	public GoldGeneral(Position pos, String owner, int face, char c) {
		super(pos, owner, face, c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public HashMap<Integer, Position> getAvailablePosition(char[][] chess) {
		HashMap<Integer, Position> GAP = new HashMap<Integer, Position>();

		Position pos = new Position();

		pos.assign(this.pos);
		pos.y -= (face);
		if (isValidPosition(pos, chess))
			GAP.put(1, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.y -= (face);
		pos.x += (face);
		if (isValidPosition(pos, chess))
			GAP.put(2, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.x += (face);
		if (isValidPosition(pos, chess))
			GAP.put(3, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.y += (face);
		if (isValidPosition(pos, chess))
			GAP.put(4, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.x -= (face);
		if (isValidPosition(pos, chess))
			GAP.put(5, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.y -= (face);
		pos.x -= (face);
		if (isValidPosition(pos, chess))
			GAP.put(6, pos);
		// TODO Auto-generated method stub
		return GAP;
	}

}
