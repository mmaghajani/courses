import java.util.HashMap;

public class Pawn extends Man {

	public Pawn(Position pos, String owner, int face, char c) {
		super(pos, owner, face, c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public HashMap<Integer, Position> getAvailablePosition(char[][] chess) {
		HashMap<Integer, Position> GAP = new HashMap<Integer, Position>();

		Position pos = new Position();
		pos.assign(this.pos);
		pos.y = pos.y - (face);
		if (isValidPosition(pos, chess))
			GAP.put(1, pos);

		return GAP;
	}

}
