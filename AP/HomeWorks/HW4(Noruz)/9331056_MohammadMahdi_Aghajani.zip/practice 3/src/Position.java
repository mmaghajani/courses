
public class Position {
	int x ;
	int y ;
	
	Position( int xPos , int yPos ){
		x = xPos ;
		y = yPos ;
	}
	
	Position(){
		x = -1 ;
		y = -1 ;
	}
	
	public boolean equals( Position pos ){
		if( x == pos.x && y == pos.y )
			return true ;
		else 
			return false ;
	}
	
	public void assign( Position pos ){
		if (pos.x != -1 && pos.y != -1) {
			x = pos.x;
			y = pos.y;
		}
	}
	
	public void reset(){
		x = -1 ;
		y = -1 ;
	}
	
}

