
public enum Face {
	North(1) , South(-1) ;
	
	private int value ;
	private Face( int value ){
		this.value = value ; 
	}
	
	public int getValue(){
		return value ;
	}
}
