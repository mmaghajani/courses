import java.util.HashMap;

abstract public class Man {

	protected Position pos;
	protected String owner;
	protected int face ;
	protected char shownChar ;

	public Man(Position pos, String owner , int face , char c ) {
		this.pos = new Position(pos.x, pos.y);
		this.owner = owner;
		this.face = face ;
		
		if( owner == "first" )
			shownChar = c ;
		else
			shownChar = (char)( c + 32 ) ;
	}

	public Position getPos() {
		return pos;
	}

	public void setPos(Position pos) {
		this.pos = pos;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public char getShownChar(){
		return shownChar ;
	}
	
	public void setShownChar( char c ){
		shownChar = c ;
	}
	
	protected boolean isValidPosition(Position pos , char[][] chess) {
		if (pos.x > 8 || pos.x < 0 || pos.y > 8 || pos.y < 0)
			return false;
		else {
			if (owner == "first") {
				if ((int) chess[pos.y][pos.x] >= 65
						&& (int) chess[pos.y][pos.x] <= 90)
					return false;
				else
					return true;
			} else {
				if ((int) chess[pos.y][pos.x] >= 97
						&& (int) chess[pos.y][pos.x] <= 122)
					return false;
				else
					return true;
			}
		}
	}

	abstract public HashMap<Integer, Position> getAvailablePosition(char[][] chess);
}
