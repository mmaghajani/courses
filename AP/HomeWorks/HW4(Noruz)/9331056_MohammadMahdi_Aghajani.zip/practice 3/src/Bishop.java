import java.util.HashMap;

public class Bishop extends Man {

	public Bishop(Position pos, String owner, int face, char c) {
		super(pos, owner, face, c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public HashMap<Integer, Position> getAvailablePosition(char[][] chess) {
		HashMap<Integer, Position> GAP = new HashMap<Integer, Position>();

		for (int i = 1; i < 9; i++) {
			Position pos = new Position();
			pos.assign(this.pos);
			pos.y -= (face * i);
			pos.x -= (face * i);
			if (isValidPosition(pos, chess))
				GAP.put(i, pos);
			if( pos.x >= 0 && pos.x < 9 && pos.y < 9 && pos.y >= 0)
				if( chess[pos.y][pos.x] != '-' )
					break ;
		}

		for (int i = 1; i < 9; i++) {
			Position pos = new Position();
			pos.assign(this.pos);
			pos.y += (face * i);
			pos.x += (face * i);
			if (isValidPosition(pos, chess))
				GAP.put(i + 8, pos);
			if( pos.x >= 0 && pos.x < 9 && pos.y < 9 && pos.y >= 0)
				if( chess[pos.y][pos.x] != '-' )
					break ;
		}

		for (int i = 1; i < 9; i++) {
			Position pos = new Position();
			pos.assign(this.pos);
			pos.x -= (face * i);
			pos.y += (face * i);
			if (isValidPosition(pos, chess))
				GAP.put(i + 16, pos);
			if( pos.x >= 0 && pos.x < 9 && pos.y < 9 && pos.y >= 0)
				if( chess[pos.y][pos.x] != '-' )
					break ;
		}

		for (int i = 1; i < 9; i++) {
			Position pos = new Position();
			pos.assign(this.pos);
			pos.x += (face * i);
			pos.y -= (face * i);
			if (isValidPosition(pos, chess))
				GAP.put(i + 24, pos);
			if( pos.x >= 0 && pos.x < 9 && pos.y < 9 && pos.y >= 0)
				if( chess[pos.y][pos.x] != '-' )
					break ;
		}

		return GAP;
	}

}
