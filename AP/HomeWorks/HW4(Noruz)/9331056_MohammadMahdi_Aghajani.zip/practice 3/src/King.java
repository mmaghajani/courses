import java.util.HashMap;

public class King extends Man {

	public King(Position pos, String owner, int face, char c) {
		super(pos, owner, face, c);
	}

	@Override
	public HashMap<Integer, Position> getAvailablePosition(char[][] chess) {
		HashMap<Integer, Position> GAP = new HashMap<Integer, Position>();

		Position pos = new Position();

		pos.assign(this.pos);
		pos.y--;
		if (isValidPosition(pos, chess))
			GAP.put(1, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.y--;
		pos.x++;
		if (isValidPosition(pos, chess))
			GAP.put(2, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.x++;
		if (isValidPosition(pos, chess))
			GAP.put(3, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.y++;
		pos.x++;
		if (isValidPosition(pos, chess))
			GAP.put(4, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.y++;
		if (isValidPosition(pos, chess))
			GAP.put(5, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.y++;
		pos.x--;
		if (isValidPosition(pos, chess))
			GAP.put(6, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.x--;
		if (isValidPosition(pos, chess))
			GAP.put(7, pos);

		pos = new Position();
		pos.assign(this.pos);
		pos.y--;
		pos.x--;
		if (isValidPosition(pos, chess))
			GAP.put(8, pos);
		// TODO Auto-generated method stub
		return GAP;
	}

}
