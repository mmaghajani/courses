import java.util.HashMap;

public class SilverGeneral extends Man {

	public SilverGeneral(Position pos, String owner, int face, char c) {
		super(pos, owner, face, c);
		// TODO Auto-generated constructor stub
	}

	@Override
	public HashMap<Integer, Position> getAvailablePosition(char[][] chess) {
		HashMap<Integer, Position> GAP = new HashMap<Integer, Position>();

		Position pos1 = new Position();
		pos1.assign(this.pos);
		pos1.y -= face;
		if (isValidPosition(pos1, chess))
			GAP.put(1, pos1);

		Position pos2 = new Position();
		pos2.assign(this.pos);
		pos2.y -= face;
		pos2.x += face;
		if (isValidPosition(pos2, chess))
			GAP.put(2, pos2);

		Position pos3 = new Position();
		pos3.assign(this.pos);
		pos3.y += face;
		pos3.x += face;
		if (isValidPosition(pos3, chess))
			GAP.put(3, pos3);

		Position pos4 = new Position();
		pos4.assign(this.pos);
		pos4.y += face;
		pos4.x -= face;
		if (isValidPosition(pos4, chess))
			GAP.put(4, pos4);

		Position pos5 = new Position();
		pos5.assign(this.pos);
		pos5.y -= face;
		pos5.x -= face;
		if (isValidPosition(pos5, chess))
			GAP.put(5, pos5);
		// TODO Auto-generated method stub
		return GAP;
	}

}
