#include <iostream>
using namespace std ;
int main()
{
	int large1 = -2147483648 , large2 = -2147483648 , n ;
		
	for( int i = 1 ; i <= 10 ; i++ )
	{
		cout << " Pls Enter Number " << i << ":";
		
		cin >> n ;
		
		if( n >= large1 )	large2  = large1 , large1 = n ;
		else if( n <= large1 && n >= large2 )	large2 = n ;
	}
	
	cout << " First largest number is : " << large1 << endl ;
	cout << " Second largest number is : " << large2 << endl ;
	
	return 0 ;
}
