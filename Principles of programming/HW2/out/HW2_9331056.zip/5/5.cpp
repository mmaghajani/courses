#include <iostream>
#include <conio.h>
using namespace std;
int main()
{
	cout << "gahi mishe ke to halghe binahayat stop working mideh ! vali alan haminjoori edame mide va az ye jaee be bad sefr mishe! " << endl ;
	
	long long i = 2 ;
	while( i < i+1 )
	{
		cout << i << " " ;
		i *= 2 ;
	}
	
	getch();
	return 0 ;
}
